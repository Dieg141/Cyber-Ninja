# Javascript-1IMA
Enkelt javascript spill for 1IMA
